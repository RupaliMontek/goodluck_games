<!-- app/Views/maintenance_page.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Maintenance</title>
</head>
<body style="padding:0;">
    <div style="text-align: center;">
        <img width="80%" height="auto" src="<?= base_url("frontend/images/maintanance2.jpg") ?>" alt="Maintenance Image">
    </div>
</body>
</html>
 