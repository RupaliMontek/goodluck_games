<style>
    .btn-align-superadmin-dashboard {
    align-items: right;
    align-content: right;
    margin-left: 620px;
}
.h3{
    font-size: 1.75rem;
    margin-left: 550px;
}
.number-buttons{
    font-size: 1.75rem;
    margin-top: 50px;
}
</style> 
<body>
    
    <?php echo form_open(base_url('superadmin/saveIndices')  ,
 array('class' => 'form-horizontal form-groups-bordered validate',
 'enctype' => 'multipart/form-data', 'method' => 'post' ));?>
<!--form id="newsForm" action="<?= site_url('superadmin/saveIndices') ?>" method="POST" enctype="multipart/form-data"-->
<div class="col-auto col-md-9">
        <div class="container mt-5">  
           <div id="counter"></div>
           <div id="verifiBtn"></div>
        <h1>Dashboard Super Admin</h1>
        <h3>Last Ten Result - 1,5,0,0,8,6,3,2,4</h3>
        
        <div class="number-line">
    <div class="number-buttons">
        <input type="checkbox" id="number0" name="number0" onclick="selectNumber(0)"><label for="number0">0</label>
        <input type="checkbox" id="number1" name="number1"  onclick="selectNumber(1)"><label for="number1">1</label>
        <input type="checkbox" id="number2" name="number2"  onclick="selectNumber(2)"><label for="number2">2</label>
        <input type="checkbox" id="number3" name="number3"  onclick="selectNumber(3)"><label for="number3">3</label>
        <input type="checkbox" id="number4" name="number4"  onclick="selectNumber(4)"><label for="number4">4</label>
        <input type="checkbox" id="number5" name="number5"  onclick="selectNumber(5)"><label for="number5">5</label>
        <input type="checkbox" id="number6" name="number6"  onclick="selectNumber(6)"><label for="number6">6</label>
        <input type="checkbox" id="number7" name="number7"  onclick="selectNumber(7)"><label for="number7">7</label>
        <input type="checkbox" id="number8" name="number8"  onclick="selectNumber(8)"><label for="number8">8</label>
        <input type="checkbox" id="number9" name="number9"  onclick="selectNumber(9)"><label for="number9">9</label>
        
        <!--<span id="chosenNumbers"></span>-->
        <!--<button onclick="set_mode_session_value('next')" id="next" class="btn btn-primary">Next</button>-->

            </div>
        </div>
        <h4>Next Result: <span id="chosenNumbers"></span></h4>   
        <div class="btn-align-superadmin-dashboard">
        <button onclick="set_mode_session_value('high')" id="high" class="btn btn-primary">High</button>
        <button onclick="set_mode_session_value('low')" id="low" class="btn btn-primary">Low</button>.
        <button onclick="set_mode_session_value('mediam')" id="mediam"  class="btn btn-primary">Mediam</button>
        <button onclick="set_mode_session_value('2x_jackpot')" id="2x_jackpot" class="btn btn-primary">2x Jackpot</button>
        <button onclick="set_mode_session_value('next')" id="next" class="btn btn-primary">Next</button>


        </div>
        <table  class="table table-striped">
            <thead>
                 <tr id="players_playing">
                    <td></td>
                    <td>590</td>
                    <td>225</td>
                    <td>150</td>
                    <td>645</td>
                    <td>510</td>
                    <td>360</td>
                    <td>190</td>
                    <td>240</td>
                    <td>310</td>
                    <td>170</td>
                </tr>    
                <tr id="numbers">
                    <th scope="col"></th>
                    <th scope="col">1</th>
                    <th scope="col">2</th>
                    <th scope="col">3</th>
                    <th scope="col">4</th>
                    <th scope="col">5</th>
                    <th scope="col">6</th>
                    <th scope="col">7</th>
                    <th scope="col">8</th>
                    <th scope="col">9</th>
                    <th scope="col">0</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($players_list as $row): ?>
                <tr>
                    <td><?php echo $row->first_name." ".$row->last_name ; ?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr> 
            <?php  endforeach; ?> 
                 
            </tbody>
        </table>
    </div>
    </div></form>
</body>
 <script>
   var base_url = '<?php echo base_url(); ?>'; 
   var mode     = '<?php echo @$_SESSION["mode"] ?>';  
    $(document).ready(function () {
    var selectedMode = sessionStorage.getItem('selectedMode');
    if (selectedMode) {
        // Remove 'btn-warning' class from all buttons
        $('.btn').removeClass('btn-warning');

        // Add 'btn-warning' class to the button stored in session
        $('#' + selectedMode).addClass('btn-warning');
    }
        set_next_number_by_mode(mode);
         setTimeout(set_next_number_by_mode, 5000); // 5000 milliseconds = 5 seconds
        function countdown() {
            function tick() 
            {
                var counter = document.getElementById("counter");
                console.log(counter); // Check if counter is not null
                var seconds = localStorage.getItem("remainingTime") || 120;
                seconds--;
                counter.innerHTML = "0:" + (seconds < 10 ? "0" : "") + String(seconds);
                if (seconds > 0) 
                {
                    localStorage.setItem("remainingTime", seconds);
                    setTimeout(tick, 1000);
                } 
                else 
                {
                    resetCountdown(); // Reset the countdown
                }
            }

            tick();
        }

        function resetCountdown() 
        {
            // Reset countdown to one minute
            localStorage.removeItem("remainingTime");
            countdown();
        }

        countdown();

        setInterval(spinner_game_function, 1000);   

        // When the document is ready


});


function set_next_number_by_mode(mode)
{
    var lucky_draw_no = '';
   $('.btn').removeClass('btn-warning'); // Remove the class from all buttons
    $('#' + mode).addClass('btn-warning'); 
    
    if(mode=='high')
    {
       lucky_draw_no = getRandomNumber_high_Index();
    }
    else if (mode=='low') 
    {   
        
        lucky_draw_no=  getRandomNumber_low_Index();
    }
     else if (mode=='mediam') 
    {    
        lucky_draw_no=  getRandomNumber_intermediate_Index();
    }
    
    else if (mode=='2x_jackpot') 
    {   
    }
    else if (mode=='next') 
    {    
        lucky_draw_no=  getRandomNumber_next_Index();
    }
    
  alert(lucky_draw_no);  

}

// function getRandomNumber_low_Index() {
//     // Select the <tr> element by its ID
//     var $tr = $('#players_playing');
//     // Find all <td> elements within the <tr>
//     var $tds = $tr.find('td');
//     // Create an array to store numerical values and their indices
//     var numbers = [];
//     var bottomThreeIndices = [];
//     // Extract numerical values from <td> elements and store them in the array with their indices
//     $tds.each(function(index) {
//         var num = parseInt($(this).text(), 10); // Parse text content to integer
//         if (!isNaN(num)) { // Check if it's a valid number
//             numbers.push({ index: index, value: num });
//         }
//     });
//     // Sort the numbers in ascending order
//     numbers.sort(function(a, b) {
//         return a.value - b.value;
//     });
//     // Select the bottom 3 numbers
//     var bottomThree = numbers.slice(0, 3);
//     $.each(bottomThree, function(index, element) {
//         // Access each element in bottomThree
//         var currentIndex = element.index;
//         bottomThreeIndices.push(currentIndex);
//     });
//     console.log(bottomThreeIndices);
// }

function getRandomNumber_low_Index() {
    // Select the <tr> element by its ID
    var $tr = $('#players_playing');
    // Find all <td> and <th> elements within the <tr>
    var $tds = $tr.find('td');
    var $ths = $tr.siblings('#numbers').find('th');

    // Create an array to store numerical values and their indices
    var numbers = [];
    var bottomFourIndices = [];

    // Extract numerical values from <td> elements and store them in the array with their indices
    $tds.each(function(index) {
        var num = parseInt($(this).text(), 10); // Parse text content to integer
        if (!isNaN(num)) { // Check if it's a valid number
            numbers.push({ index: index, value: num });
        }
    });

    // Sort the numbers in ascending order
    numbers.sort(function(a, b) {
        return a.value - b.value;
    });

    // Select the bottom 3 numbers
    var bottomFour = numbers.slice(0, 4);

    // Cross out the bottom 3 numbers and their corresponding <th> elements
    $.each(bottomFour, function(index, element) {
        var currentIndex = element.index;
        bottomFourIndices.push(currentIndex);

        $ths.eq(currentIndex).css({
            // 'text-decoration': 'line-through',
            'background-color': 'green',
            'color': 'white', // Optionally set text color to white for better visibility
            'border': '1px solid black'
        });      });

    console.log(bottomFourIndices);
    saveIndices('low', bottomFourIndices);

}
function getRandomNumber_intermediate_Index() {
    //  resetStyling();
    // Select the <tr> element by its ID
    var $tr = $('#players_playing');
    // Find all <td> elements within the <tr>
    var $tds = $tr.find('td');
    var $ths = $tr.siblings('#numbers').find('th');
    // Create an array to store numerical values and their indices
    var numbers = [];
    var intermediateIndices = [];
    // Extract numerical values from <td> elements and store them in the array with their indices
    $tds.each(function(index) {
        var num = parseInt($(this).text(), 10); // Parse text content to integer
        if (!isNaN(num)) { // Check if it's a valid number
            numbers.push({ index: index, value: num });
        }
    });
    // Sort the numbers in ascending order
    numbers.sort(function(a, b) {
        return a.value - b.value;
    });

    var mediumThree = numbers.slice(0, 3);

    // Cross out the bottom 3 numbers and their corresponding <th> elements
    $.each(mediumThree, function(index, element) {
        var currentIndex = element.index;
        intermediateIndices.push(currentIndex);

        // Cross out the <td> element
        // $tds.eq(currentIndex).css('text-decoration', 'line-through');

        // Cross out the corresponding <th> element
        $ths.eq(currentIndex).css({
            // 'text-decoration': 'line-through',
            'background-color': 'blue',
            'color': 'white', // Optionally set text color to white for better visibility
            'border': '1px solid black'
        });      });

    console.log(intermediateIndices);
    saveIndices('intermediate', intermediateIndices);
}

function getRandomNumber_high_Index() 
{
    //  resetStyling();
// Select the <tr> element by its ID
var $tr = $('#players_playing');
// Find all <td> elements within the <tr>
var $tds = $tr.find('td');
 var $ths = $tr.siblings('#numbers').find('th');
// Create an array to store numerical values and their indices
var numbers = [];
var topThreeIndices = [];
// Extract numerical values from <td> elements and store them in the array with their indices
$tds.each(function(index) {
var num = parseInt($(this).text(), 10); // Parse text content to integer
if (!isNaN(num)) 
{ // Check if it's a valid number
    numbers.push({ index: index, value: num });
}
});
// Sort the numbers in descending order
numbers.sort(function(a, b) 
{
    return b.value - a.value;
});
var topThree = numbers.slice(0, 3);

    // Cross out the bottom 3 numbers and their corresponding <th> elements
    $.each(topThree, function(index, element) {
        var currentIndex = element.index;
        topThreeIndices.push(currentIndex);

        // Cross out the <td> element
        // $tds.eq(currentIndex).css('text-decoration', 'line-through');

        // Cross out the corresponding <th> element
        $ths.eq(currentIndex).css({
            // 'text-decoration': 'line-through',
            'background-color': 'red',
            'color': 'white', // Optionally set text color to white for better visibility
            'border': '1px solid black'
        });    
        
    });

    console.log(topThreeIndices);
    saveIndices('high', topThreeIndices);

}

function getRandomNumber_next_Index() {
    // Select the <tr> element by its ID
    var $tr = $('#players_playing');
    // Find all <td> and <th> elements within the <tr>
    var $tds = $tr.find('td');
    var $ths = $tr.siblings('#numbers').find('th');

    // Create an array to store numerical values and their indices
    var numbers = [];
    var nextIndices = [];

    // Extract numerical values from <td> elements and store them in the array with their indices
    $tds.each(function(index) {
        var num = parseInt($(this).text(), 10); // Parse text content to integer
        if (!isNaN(num)) { // Check if it's a valid number
            numbers.push({ index: index, value: num });
        }
    });

    // Sort the numbers in ascending order
    numbers.sort(function(a, b) {
        return a.value - b.value;
    });

    // Select the bottom 3 numbers
    var selectNext = numbers.slice(0, 3);

    // Cross out the bottom 3 numbers and their corresponding <th> elements
    $.each(selectNext, function(index, element) {
        var currentIndex = element.index;
        nextIndices.push(currentIndex);

        // Cross out the <td> element
        // $tds.eq(currentIndex).css('text-decoration', 'line-through');

        // Cross out the corresponding <th> element
        $ths.eq(currentIndex).css({
            // 'text-decoration': 'line-through',
            'background-color': 'white',
            'color': 'black', // Optionally set text color to white for better visibility
            'border': '1px solid black'
        });      
        
    });

    console.log(nextIndices);
    saveIndices('next', nextIndices);
}

// Select the top 3 numbers
// var topThree = numbers.slice(0, 3);
// $.each(topThree, function(index, element) {
// // Access each element in topThree
// var currentIndex = element.index;
// topThreeIndices.push(currentIndex);
// // Your code here, for example:   
// });
// $tds.each(function(index) {
//         if (topThreeIndices.includes(index)) {
//             // Apply your logic to "cross out" the number, for example, change the background color
//             $(this).css('text-decoration', 'line-through');
//         }
//     });
// // console.log(topThreeIndices);
// }
// function resetStyling() {
//     var $tr = $('#players_playing');
//     var $tds = $tr.find('td');
//     // Remove the 'line-through' style from all <td> elements
//     $tds.css('text-decoration', 'none');
// }


function spinner_game_function()
    {
        var counterElement = document.getElementById("counter");
        if (counterElement) 
        {
           var counterValue = counterElement.innerHTML;
           console.log("Counter Value:", counterValue);
           if (counterValue <= "0:10") 
           {
                disableButtons();
           }
           else
           {
                enableButtons();       
           }
        } 
        else 
        {
            console.log("Counter element not found.");
         }
    } 


function disableButtons() {
        // Disable buttons when counter reaches "0:10"
        $("#high, #low, #mediam, #2x_jackpot", "#next").prop("disabled", true);
    }

    function enableButtons() {
        // Enable buttons
        $("#high, #low, #mediam, #2x_jackpot", "#next").prop("disabled", false);
    }
function set_mode_session_value(mode)
{  
    $.ajax({
        url: base_url+'superadmin/set_mode_session',
        type: 'POST',
        data: { mode: mode, },
        success: function(response) {
            alert('Session value set successfully!');
        },
        error: function(xhr, status, error) {
            console.error('Error setting session value:', error);
        }
    });
 }   


 var $tr = $('#players_playing');

</script>
<script>
    function selectNumber(number) {
        document.getElementById("chosenNumber").textContent = number;
    }
</script>
<script>
    // Array to store selected numbers
    var selectedNumbers = [];

    function selectNumber(number) {
        // Check if the number is already selected
        var index = selectedNumbers.indexOf(number);

        if (index === -1) {
            // If not selected, add it to the array
            selectedNumbers.push(number);
        } else {
            // If already selected, remove it from the array
            selectedNumbers.splice(index, 1);
        }

        // Update the display
        updateDisplay();
    }

    function updateDisplay() {
        // Display the selected numbers in the chosenNumbers span
        var chosenNumbersSpan = document.getElementById('chosenNumbers');
        chosenNumbersSpan.textContent = selectedNumbers.join(', ');
    }
function saveIndices(scenario, indices) {
    $.ajax({
        type: 'POST',
        url: '/superadmin/saveIndices',
        data: { scenario: scenario, indices: indices },
        success: function(response) {
            console.log('Indices saved successfully:', response);
        },
        error: function(error) {
            console.error('Error saving indices:', error);
        }
    });
}
</script>